import React, { useState } from 'react';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { generateTribute } from '../services/geminiService';

const AITribute: React.FC = () => {
  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState('');
  const [memories, setMemories] = useState('');
  const [tone, setTone] = useState('Solemne y Respetuoso');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !relationship) return;

    setLoading(true);
    const text = await generateTribute(name, relationship, memories, tone);
    setResult(text);
    setLoading(false);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-brand-100">
      <div className="bg-brand-900 p-6 text-white text-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://picsum.photos/800/200?blur=5')] bg-cover"></div>
        <Sparkles className="w-8 h-8 mx-auto mb-2 text-brand-gold animate-pulse" />
        <h3 className="text-2xl font-serif font-bold">Homenaje Digital con IA</h3>
        <p className="text-brand-100 text-sm mt-2">
          Como parte de nuestra innovación, le ayudamos a encontrar las palabras perfectas para despedir a su ser querido. (Gratuito)
        </p>
      </div>

      <div className="p-6 md:p-8">
        {!result ? (
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nombre del Difunto</label>
              <input
                type="text"
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none transition"
                placeholder="Ej. María García"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Su relación</label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                  placeholder="Ej. Madre, Amigo, Abuelo"
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tono del mensaje</label>
                <select
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none bg-white"
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                >
                  <option>Solemne y Respetuoso</option>
                  <option>Celebración de Vida</option>
                  <option>Cálido y Cercano</option>
                  <option>Poético</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Recuerdos o cualidades (Opcional)</label>
              <textarea
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 outline-none"
                rows={3}
                placeholder="Ej. Amaba la jardinería, siempre sonreía, ayudaba a todos..."
                value={memories}
                onChange={(e) => setMemories(e.target.value)}
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-brand-800 hover:bg-brand-900 text-white font-medium py-3 rounded-lg transition flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" /> Generando palabras...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" /> Generar Homenaje
                </>
              )}
            </button>
          </form>
        ) : (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-brand-50 p-6 rounded-lg border border-brand-100 italic font-serif text-gray-800 leading-relaxed text-lg">
              "{result}"
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => { setResult(''); setName(''); setMemories(''); }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-600 rounded-lg hover:bg-gray-50 transition"
              >
                Crear otro
              </button>
              <button
                className="flex-1 px-4 py-2 bg-brand-gold text-white rounded-lg hover:bg-yellow-600 transition flex items-center justify-center gap-2"
                onClick={() => alert("Funcionalidad de guardado en desarrollo. Por favor copie el texto.")}
              >
                <Send className="w-4 h-4" /> Guardar / Enviar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AITribute;