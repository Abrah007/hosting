import { GoogleGenAI } from "@google/genai";

// Inicializar el cliente solo si la clave existe (manejo seguro para demo)
const apiKey = process.env.API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const generateTribute = async (
  name: string,
  relationship: string,
  memories: string,
  tone: string
): Promise<string> => {
  if (!ai) {
    // Simulación si no hay API Key configurada en el entorno de desarrollo
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`(Modo Demo - Sin API Key)\n\nEn memoria de ${name}, quien fue un ${relationship} excepcional. Recordaremos siempre: "${memories}". Que descanse en paz en su último paseíto.`);
        }, 1500);
    });
  }

  try {
    const model = 'gemini-3-flash-preview';
    const prompt = `
      Actúa como un asistente compasivo y profesional de la funeraria "Último Paseíto".
      Escribe un breve y conmovedor obituario o mensaje de homenaje para ${name}.
      Relación con el solicitante: ${relationship}.
      Recuerdos clave o características a mencionar: ${memories}.
      Tono deseado: ${tone} (ej. solemne, celebrando la vida, poético).
      
      El mensaje debe ser respetuoso, cálido y honrar su memoria. Máximo 150 palabras.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "No se pudo generar el mensaje en este momento.";
  } catch (error) {
    console.error("Error generando homenaje:", error);
    return "Lo sentimos, hubo un error al conectar con nuestro asistente inteligente. Por favor intente más tarde.";
  }
};